<?php
session_start();
//$montant=$_SESSION['solde'];
?>

<?php
include("header.php");

?>


<!-- Page Content -->
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">Création d'un nouveau client</h1>
                        </div>
						ffffffffffffffddddddddddd
						Vous venez d'inscrire <?php echo $_GET["nom"]."&nbsp; ".$_GET["prenom"];?>
							
						ddddddddddddddddddddddddd
                        <!-- /.col-lg-12 -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            <!-- /#page-wrapper -->








<?php
include("footer.php");

?>