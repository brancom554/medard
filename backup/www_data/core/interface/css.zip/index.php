<?php
@header("Locaion:settings-profile.php");

?>