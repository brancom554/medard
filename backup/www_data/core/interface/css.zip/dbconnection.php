<?php
$con = @mysql_connect("localhost","iinbnkgr_dbuser","cotonou2015");
if (!$con)
  {
  die('Could not connect: '.mysql_error());
  }

@mysql_select_db("iinbnkgr_db");
?>

